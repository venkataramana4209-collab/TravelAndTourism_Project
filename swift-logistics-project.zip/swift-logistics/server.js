const express = require('express');
const session = require('express-session');
const flash   = require('connect-flash');
const bcrypt  = require('bcryptjs');
const path    = require('path');

const app  = express();
const PORT = 3000;

// ── In-memory "DB" (no real DB needed for minor project) ────────────────
const users    = [];
const shipments = [];

// ── Service rate card (per kg in ₹) ────────────────────────────────────
const RATES = {
  road:       25,
  rail:       18,
  air:       120,
  sea:        10,
  express:   200,
  lastmile:   40
};

const SERVICE_LABELS = {
  road:     'Road Freight',
  rail:     'Rail Cargo',
  air:      'Air Express',
  sea:      'Sea Cargo',
  express:  'Express Overnight',
  lastmile: 'Last-Mile Delivery'
};

// ── Middleware ──────────────────────────────────────────────────────────
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(session({
  secret: 'swift-logistics-secret-2024',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 24 * 60 * 60 * 1000 }
}));
app.use(flash());

app.use((req, res, next) => {
  res.locals.user    = req.session.user || null;
  res.locals.success = req.flash('success');
  res.locals.error   = req.flash('error');
  next();
});

function isLoggedIn(req, res, next) {
  if (req.session.user) return next();
  req.flash('error', 'Please login to continue');
  res.redirect('/login');
}

// ── HELPERS ─────────────────────────────────────────────────────────────
function genAWB() {
  return 'SWF' + Date.now().toString().slice(-8);
}

function getTimeline(bookedAt) {
  const base = new Date(bookedAt);
  const add  = (h) => new Date(base.getTime() + h * 3600000)
    .toLocaleString('en-IN', { day:'2-digit', month:'short', hour:'2-digit', minute:'2-digit' });
  return [
    { stage: 'Booked',           time: add(0),  loc: 'Origin Hub',       done: true  },
    { stage: 'Picked Up',        time: add(4),  loc: 'Sender Address',   done: true  },
    { stage: 'In Transit',       time: add(12), loc: 'City Sorting Hub', done: true  },
    { stage: 'Out for Delivery', time: add(36), loc: 'Destination City', done: false },
    { stage: 'Delivered',        time: add(48), loc: 'Receiver Address', done: false },
  ];
}

// ── ROUTES ──────────────────────────────────────────────────────────────

// Home
app.get('/', (req, res) => res.render('home'));

// Services
app.get('/services', (req, res) => res.render('services'));

// Login
app.get('/login', (req, res) => {
  if (req.session.user) return res.redirect('/');
  res.render('login', { mode: 'login' });
});
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email);
  if (!user) { req.flash('error', 'No account found with this email.'); return res.redirect('/login'); }
  const ok = await bcrypt.compare(password, user.password);
  if (!ok)  { req.flash('error', 'Incorrect password. Try again.'); return res.redirect('/login'); }
  req.session.user = { name: user.name, email: user.email };
  req.flash('success', `Welcome back, ${user.name}!`);
  res.redirect('/');
});

// Register
app.get('/register', (req, res) => {
  if (req.session.user) return res.redirect('/');
  res.render('login', { mode: 'register' });
});
app.post('/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (users.find(u => u.email === email)) {
    req.flash('error', 'Email already registered. Please login.');
    return res.redirect('/register');
  }
  const hashed = await bcrypt.hash(password, 10);
  users.push({ name, email, password: hashed });
  req.session.user = { name, email };
  req.flash('success', `Account created! Welcome aboard, ${name}!`);
  res.redirect('/');
});

// Logout
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

// Booking - GET
app.get('/booking', isLoggedIn, (req, res) => {
  res.render('booking', { rates: RATES, labels: SERVICE_LABELS });
});

// Booking - POST
app.post('/booking', isLoggedIn, (req, res) => {
  const { senderName, senderCity, senderPhone,
          receiverName, receiverCity, receiverPhone,
          weight, serviceType, pickupDate, description } = req.body;
  const rate   = RATES[serviceType] || 25;
  const price  = Math.round(parseFloat(weight) * rate);
  const awb    = genAWB();
  const booking = {
    awb, userEmail: req.session.user.email,
    senderName, senderCity, senderPhone,
    receiverName, receiverCity, receiverPhone,
    weight, serviceType,
    serviceLabel: SERVICE_LABELS[serviceType],
    pickupDate, description: description || '—',
    price, bookedAt: new Date().toISOString(),
    status: 'Booked'
  };
  shipments.push(booking);
  res.redirect(`/payment?awb=${awb}`);
});

// Payment - GET
app.get('/payment', isLoggedIn, (req, res) => {
  const { awb } = req.query;
  const shipment = shipments.find(s => s.awb === awb);
  if (!shipment) return res.redirect('/booking');
  res.render('payment', { shipment });
});

// Payment - POST
app.post('/payment', isLoggedIn, (req, res) => {
  const { awb } = req.body;
  const shipment = shipments.find(s => s.awb === awb);
  if (!shipment) return res.redirect('/booking');
  shipment.status = 'Confirmed';
  res.render('confirmation', { shipment });
});

// Tracking - GET
app.get('/tracking', (req, res) => {
  const { awb } = req.query;
  let shipment = null, timeline = null;
  if (awb) {
    shipment = shipments.find(s => s.awb === awb.toUpperCase().trim());
    if (shipment) timeline = getTimeline(shipment.bookedAt);
  }
  res.render('tracking', { awb: awb || '', shipment, timeline });
});

// Start
app.listen(PORT, () => {
  console.log('\n🚚 Swift Logistics is running!');
  console.log(`👉 Open: http://localhost:${PORT}\n`);
});
