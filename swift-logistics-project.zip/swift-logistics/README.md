# 🚚 SwiftLog — Transportation & Logistics Minor Project

## Project Structure
```
swift-logistics/
├── server.js              ← Backend (Node.js + Express)
├── package.json           ← Dependencies
├── public/
│   └── css/
│       └── style.css      ← All CSS styles
└── views/
    ├── home.ejs            ← Home Page
    ├── services.ejs        ← Services Page
    ├── login.ejs           ← Login & Register Page
    ├── booking.ejs         ← Shipment Booking Page
    ├── tracking.ejs        ← Shipment Tracking Page
    ├── payment.ejs         ← Payment Page
    ├── confirmation.ejs    ← Booking Confirmed Page
    └── partials/
        ├── header.ejs      ← Navbar (all pages lo shared)
        └── footer.ejs      ← Footer (all pages lo shared)
```

---

## ⚙️ VS Code లో Run చేయడం — Step by Step

### Step 1 — Node.js Install చేయండి
👉 https://nodejs.org వెళ్ళి **LTS** version download చేసి install చేయండి.
Install అయిన తర్వాత PC restart చేయండి.

### Step 2 — VS Code లో Open చేయండి
1. VS Code open చేయండి
2. **File → Open Folder** click చేయండి
3. `swift-logistics` folder select చేయండి → **Open** click చేయండి

### Step 3 — Terminal Open చేయండి
VS Code లో: **Ctrl + `** (backtick key — keyboard లో 1 కి left side లో ఉంటుంది)
లేదా: **View → Terminal** menu లో click చేయండి

### Step 4 — Dependencies Install చేయండి
Terminal లో ఇలా type చేయండి:
```
npm install
```
Enter నొక్కండి. Internet connection అవసరం. కొంచెం time తీసుకుంటుంది.

### Step 5 — Server Start చేయండి
```
npm start
```
ఇలా message కనిపిస్తుంది:
```
🚚 Swift Logistics is running!
👉 Open: http://localhost:3000
```

### Step 6 — Browser లో Open చేయండి
Chrome లేదా Firefox open చేసి ఇలా type చేయండి:
```
http://localhost:3000
```

---

## 📄 Pages & URLs

| Page | URL |
|------|-----|
| Home | http://localhost:3000 |
| Services | http://localhost:3000/services |
| Login | http://localhost:3000/login |
| Register | http://localhost:3000/register |
| Book Shipment | http://localhost:3000/booking |
| Track Shipment | http://localhost:3000/tracking |
| Payment | Book చేసిన తర్వాత automatically వస్తుంది |

---

## ✅ Features List

- ✅ Home Page — Hero, Stats, Services, Features, CTA
- ✅ Services Page — 6 service cards with images and pricing
- ✅ Login + Register — Split screen design, password hashing
- ✅ Shipment Booking — Sender/Receiver/Weight/Service form + live price calculator
- ✅ Tracking Page — AWB search with 5-stage timeline
- ✅ Payment Page — Card formatting, GST + Insurance breakdown
- ✅ Confirmation Page — AWB number + tracking link
- ✅ Session Management — Login state maintained
- ✅ Flash Messages — Error/Success alerts

## ❌ Server Stop చేయడానికి
Terminal లో **Ctrl + C** నొక్కండి.

---

Made with ❤️ for Minor Project — Transportation & Logistics
